function encryptPassword()
{ 
    var txtpassword = $('#txtPass').val(); 
    var txtName=$('#txtName').val();
    var txtCaptcha=$('#DNTCaptchaInputText').val();
    if(txtpassword != '' && txtName !='' && txtCaptcha !='') 
    {
        var key = CryptoJS.enc.Utf8.parse('8056483646328763');
        var iv = CryptoJS.enc.Utf8.parse('8056483646328763');
        var encryptedpassword = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(txtpassword), key,  
        { 
        keySize: 128 / 8,   
        iv: iv,  
        mode: CryptoJS.mode.CBC,  
        padding: CryptoJS.pad.Pkcs7
        }).toString();
        $('#txtPass').val(encryptedpassword);   
    }
}