﻿namespace RGI.IdentityServer.WebApp
{
    public static class AppConfig
    {
        public static string RelianceProvisionApi { get; set; }

        public static string RelianceProvisionApiKey { get; set; }

        public static string GHIPUserStatusApi { get; set; }

        public static string GHIPUserStatusApiKey { get; set; }

        public static string ADByPassUsers { get; set; }

        public static string LipProvisionApi { get; set; }

        public static string LipProvisionAddUserApi { get; set; }
    }
}
