﻿using System.Text;

namespace RGI.IdentityServer.WebApp.Utility
{
    public static class OtpUtility
    {
        public static readonly string[] AllowedOtpChar = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };

        public static string GenerateRandomOTP(int otpLength, string[] allowedCharacters)
        {
            StringBuilder bld = new StringBuilder();

            string tempChars = string.Empty;

            for (int i = 0; i < otpLength; i++)
            {
                ThreadSafeRandom.Next(0, allowedCharacters.Length);

                tempChars = allowedCharacters[ThreadSafeRandom.Next(0, allowedCharacters.Length)];

                bld.Append(tempChars);
            }

            return bld.ToString();
        }
    }
}
