namespace RGI.IdentityServer.WebApp.Utility
{
    public interface IDecryptUtility
    {
        public string DecryptText(string key, string cipherText);

        public string DecryptPasswordAES(string cipherText);
    }
}