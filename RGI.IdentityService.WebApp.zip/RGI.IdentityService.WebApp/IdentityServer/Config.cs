﻿using System.Collections.Generic;
using IdentityServer4.Models;

namespace RGI.IdentityServer.WebApp
{
    public static class Config
    {
        public static IEnumerable<IdentityResource> Ids =>
           new List<IdentityResource>
           {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
           };

        public static IEnumerable<ApiResource> Apis =>
            new List<ApiResource>
            {
                new ApiResource("GhipApi", "Ghip API collection"),
            };

        public static IEnumerable<Client> Clients =>
            new List<Client>
            {
                 // local reliance
                 new Client
                {
                    RequireConsent = false,
                    ClientId = "GhipLocal",
                    ClientName = "Ghip Client",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    AllowedScopes = { "openid", "profile", "GhipApi" },
                    RedirectUris = { "http://localhost:4200/auth-callback/", "https://localhost:4200/auth-callback/" },
                    PostLogoutRedirectUris = { "http://localhost:4200/", "https://localhost:4200/" },
                    AllowedCorsOrigins = { "http://localhost:4200", "https://localhost:4200" },
                    AllowAccessTokensViaBrowser = true,
                    AccessTokenLifetime = 3600,
                },

                 // reliance
                 new Client
                {
                    RequireConsent = false,
                    ClientId = "Ghip",
                    ClientName = "Ghip Client",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    AllowedScopes = { "openid", "profile", "GhipApi" },
                    RedirectUris = { "https://ghipprod.azurewebsites.net/auth-callback/" },
                    PostLogoutRedirectUris = { "https://ghipprod.azurewebsites.net/" },
                    AllowedCorsOrigins = { "http://ghipprod.azurewebsites.net", "https://ghipprod.azurewebsites.net" },
                    AllowAccessTokensViaBrowser = true,
                    AccessTokenLifetime = 3600,
                },

                     // reliance
                 new Client
                {
                    RequireConsent = false,
                    ClientId = "GhipDev",
                    ClientName = "Ghip Client",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    AllowedScopes = { "openid", "profile", "GhipApi" },
                    RedirectUris = { "https://ghipdevlp.azurewebsites.net/auth-callback/" },
                    PostLogoutRedirectUris = { "https://ghipdevlp.azurewebsites.net/" },
                    AllowedCorsOrigins = { "http://ghipdevlp.azurewebsites.net", "https://ghipdevlp.azurewebsites.net" },
                    AllowAccessTokensViaBrowser = true,
                    AccessTokenLifetime = 3600,
                },
            };

        public static string EmailSendApi { get; set; }

        public static string EmailSendApiKey { get; set; }
    }
}
