﻿using System.Threading.Tasks;

namespace RGI.IdentityServer.WebApp.Services
{
    public interface IOtpService
    {
        public Task<string> GenerateOtpAsync(string id);

        public Task SaveUserEmail(string userId, string email);
    }
}
