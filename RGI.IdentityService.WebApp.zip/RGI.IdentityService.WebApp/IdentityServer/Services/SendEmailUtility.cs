﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using RGI.IdentityServer.WebApp.Models;

namespace RGI.IdentityServer.WebApp.Services
{
    public class SendEmailUtility : ISendEmailUtility
    {
        public IActionResult SendEmailWithApi(EmailModel emailModel)
        {
            string url = Config.EmailSendApi;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("api_key", Config.EmailSendApiKey);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(Newtonsoft.Json.JsonConvert.SerializeObject(emailModel));
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "Accepted")
            {
                return new OkResult();
            }
            else
            {
                return new BadRequestObjectResult(response.ErrorMessage);
            }
        }

        public string GetForgetEmailTemplate(string callback)
        {
            string template = $"Dear Member,<br/><br/> To reset your password  <a href={callback}>click here</a> <br/>"
                             + "The link will be valid for next 15 mins.<br/><br/> Yours Sincerely, <br/>" +
                             "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;font-weight:bold; font-size:14.6667px; background-color: #ffffff;\">Team RCare Health</span><br/>" +
                             "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;font-weight:bold; font-size:14.6667px; background-color: #ffffff;\"> Reliance General Insurance Co. Ltd.</span><br/><br/>" +
                            "Email: rgicl.rcarehealth@relianceada.com <br/>" + "Chat@Website:https://www.reliancegeneral.co.in/Insurance/Home.aspx>>Chat<br/>" +
                            "Address: Reliance General Insurance,<br/> RCare Health,<br/>No.1-89/3/B/40 to 42/KS/301, 3rd floor, <br/>Krishe Block, Krishe Sapphire, Madhapur,<br/>" +
                            "Hyderabad-Telangana-500081";
            return template;
        }

        public string GetOtpEmailTemplate(string otp)
        {
            string template = $"Hi, your one time password is {otp} , It will be valid for 10 mins.";
            return template;
        }
    }
}
