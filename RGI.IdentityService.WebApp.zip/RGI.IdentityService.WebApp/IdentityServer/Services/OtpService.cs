﻿using System;
using System.Linq;
using System.Threading.Tasks;
using RGI.IdentityServer.WebApp.Data;
using RGI.IdentityServer.WebApp.Utility;

namespace RGI.IdentityServer.WebApp.Services
{
    public class OtpService : IOtpService
    {
        private readonly AppIdentityDbContext _db;

        public OtpService(AppIdentityDbContext db)
        {
            _db = db;
        }

        public async Task<string> GenerateOtpAsync(string id)
        {
            var otp = OtpUtility.GenerateRandomOTP(6, OtpUtility.AllowedOtpChar);

            var entity = _db.Users.Where(x => x.Id == id).Single();
            entity.LastOtpSentAt = DateTime.UtcNow;
            entity.Otp = otp;
            entity.OtpExpiry = DateTime.UtcNow.AddMinutes(10);

            await _db.SaveChangesAsync();
            return otp;
        }

        public async Task SaveUserEmail(string userId, string email)
        {
            var entity = _db.Users.Where(x => x.Id == userId).Single();
            entity.Email = email;

            await _db.SaveChangesAsync();
        }
    }
}
