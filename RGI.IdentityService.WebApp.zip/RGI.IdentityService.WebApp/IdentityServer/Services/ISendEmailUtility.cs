﻿using Microsoft.AspNetCore.Mvc;
using RGI.IdentityServer.WebApp.Models;

namespace RGI.IdentityServer.WebApp.Services
{
    public interface ISendEmailUtility
    {
        public IActionResult SendEmailWithApi(EmailModel emailModel);

        public string GetForgetEmailTemplate(string callback);

        public string GetOtpEmailTemplate(string otp);
    }
}
