namespace RGI.IdentityServer.WebApp.Models
{
    public class DecryptionModel
    {
        public string Key = "b14ca5898a4e4133bbce2ea2315a1916";

        public string Username { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }
    }
}
