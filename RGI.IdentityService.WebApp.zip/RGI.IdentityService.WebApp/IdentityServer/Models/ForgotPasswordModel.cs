﻿using System.ComponentModel.DataAnnotations;

namespace RGI.IdentityServer.WebApp.Models
{
    public class ForgotPasswordModel
    {
        [Required]
        public string UserName { get; set; }
    }
}
