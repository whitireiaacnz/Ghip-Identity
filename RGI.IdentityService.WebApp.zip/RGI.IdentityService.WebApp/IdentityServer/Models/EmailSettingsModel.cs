﻿using Newtonsoft.Json;

namespace RGI.IdentityServer.WebApp.Models
{
    public class EmailSettingsModel
    {
        [JsonProperty("Footer")]
        public int Footer { get; set; } = 1;

        [JsonProperty("clicktrack")]
        public int Clicktrack { get; set; } = 0;

        [JsonProperty("opentrack")]
        public int Opentrack { get; set; } = 1;

        [JsonProperty("unsubscribe")]
        public int Unsubscribe { get; set; } = 0;

        [JsonProperty("bcc")]
        public string Bcc { get; set; }
    }
}