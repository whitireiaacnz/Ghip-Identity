﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace RGI.IdentityServer.WebApp.Models
{
    public class EmailModel
    {
        [JsonProperty("subject")]
        public string Subject { get; set; }

        [JsonProperty("content")]
        public string Content { get; set; }

        [JsonProperty("from")]
        public EmailFromModel From { get; set; } = new EmailFromModel();

        [JsonProperty("personalizations")]
        public List<EmailPersonalizationsModel> Personalizations { get; set; } = new List<EmailPersonalizationsModel>();

        [JsonProperty("settings")]
        public EmailSettingsModel Settings { get; set; } = new EmailSettingsModel();
    }
}
