﻿namespace RGI.IdentityServer.WebApp.Models
{
    public class ResetPasswordByApiModel
    {
        public string UserName { get; set; }

        public string NewPassword { get; set; }

        public string Id { get; set; }
    }
}
