﻿namespace RGI.IdentityServer.WebApp.Models
{
    public class RedirectViewModel
    {
        public string RedirectUrl { get; set; }
    }
}
