﻿using System;

namespace RGI.IdentityServer.WebApp.Models
{
    public class SSODecryptCredModel
    {
        public string IdentityServerId { get; set; }

        public string UserName { get; set; }

        public DateTime IssueDate { get; set; }
    }
}
