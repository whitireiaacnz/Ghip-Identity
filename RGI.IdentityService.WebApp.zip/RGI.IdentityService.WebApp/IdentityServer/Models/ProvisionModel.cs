﻿using System.ComponentModel.DataAnnotations;

namespace RGI.IdentityServer.WebApp.Models
{
    public class ProvisionModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        public string Email { get; set; }

        public string WebsiteLoggedIn { get; set; }

        public int UserRole { get; set; }
    }
}
