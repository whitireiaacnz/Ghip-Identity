﻿using System.ComponentModel.DataAnnotations;

namespace RGI.IdentityServer.WebApp.Models
{
    public class OtpModel
    {
        [Required]
        public string TwoFactorCode { get; set; }

        public string UserId { get; set; }

        public string ReturnUrl { get; set; }

        public string UserName { get; set; }
    }
}
