// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.

using System.ComponentModel.DataAnnotations;
using DNTCaptcha.Core.Contracts;

namespace RGI.IdentityServer.WebApp.Models
{
    public class LoginInputModel : DNTCaptchaBase
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        public string LoginType { get; set; }

        public string Role { get; set; }

        public bool RememberLogin { get; set; }

        public string ReturnUrl { get; set; }
    }
}