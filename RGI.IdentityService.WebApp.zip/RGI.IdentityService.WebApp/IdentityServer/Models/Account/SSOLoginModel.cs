﻿using System.ComponentModel.DataAnnotations;

namespace RGI.IdentityServer.WebApp.Models.Account
{
    public class SSOLoginModel
    {
        public string UserName { get; set; }

        public string LoginType { get; set; }

        public string Role { get; set; }

        public bool RememberLogin { get; set; }

        public string ReturnUrl { get; set; }
    }
}
