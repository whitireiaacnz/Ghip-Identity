﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace RGI.IdentityServer.WebApp.Models
{
    public class EmailPersonalizationsModel
    {
        [JsonProperty("recipient")]
        public string Recipient { get; set; }

        [JsonProperty("recipient_cc")]
        public List<string> Recipient_cc { get; set; } = new List<string>();
    }
}