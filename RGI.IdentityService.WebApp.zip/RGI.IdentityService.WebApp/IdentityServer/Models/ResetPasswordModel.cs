﻿using System.ComponentModel.DataAnnotations;

namespace RGI.IdentityServer.WebApp.Models
{
    public class ResetPasswordModel
    {
        [Required]
        [DataType(DataType.Password)]
        [MinLength(14)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        [MinLength(14)]
        public string ConfirmPassword { get; set; }

        public string Email { get; set; }

        public string UserName { get; set; }

        public string Token { get; set; }

        public string Error { get; set; }
    }
}
