﻿namespace RGI.IdentityServer.WebApp.Models
{
    public class ErrorModel
    {
        public string ErrorMessage { get; set; }
    }
}
