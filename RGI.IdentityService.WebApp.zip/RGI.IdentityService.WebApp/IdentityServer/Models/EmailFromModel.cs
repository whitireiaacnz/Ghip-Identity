﻿using Newtonsoft.Json;

namespace RGI.IdentityServer.WebApp.Models
{
    public class EmailFromModel
    {
        [JsonProperty("fromEmail")]
        public string FromEmail { get; set; } = "no-reply-corp@reliancegeneral.co.in";

        [JsonProperty("fromName")]
        public string FromName { get; set; } = "GHIP";
    }
}