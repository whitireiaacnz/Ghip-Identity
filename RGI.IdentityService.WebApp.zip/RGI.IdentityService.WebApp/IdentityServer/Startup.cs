﻿using System;
using System.Linq;
using System.Reflection;
using AspNetCore.ReCaptcha;
using DNTCaptcha.Core;
using IdentityServer4;
using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Mappers;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RGI.IdentityServer.WebApp.Data;
using RGI.IdentityServer.WebApp.InDB.Data;
using RGI.IdentityServer.WebApp.Services;
using RGI.IdentityServer.WebApp.Utility;

namespace RGI.IdentityServer.WebApp.InDB
{
    public class Startup
    {
        public Startup(IWebHostEnvironment environment, IConfiguration configuration)
        {
            Environment = environment;
            Configuration = configuration;
        }

        public IWebHostEnvironment Environment { get; }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            // var cert = new X509Certificate2(Path.Combine(Environment.ContentRootPath, "idsrv4test.pfx"), "your_cert_password");
            services.AddReCaptcha(Configuration.GetSection("ReCaptcha"));
            services.AddDNTCaptcha(options =>
            options.UseCookieStorageProvider());
            services.AddControllersWithViews();

            services.AddDbContext<AppIdentityDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("SQL")));
            AppConfig.RelianceProvisionApi = Configuration.GetConnectionString("RelianceProvisionApi");
            AppConfig.RelianceProvisionApiKey = Configuration.GetConnectionString("RelianceProvisionApiKey");
            AppConfig.GHIPUserStatusApi = Configuration.GetConnectionString("GHIPUserStatusApi");
            AppConfig.GHIPUserStatusApiKey = Configuration.GetConnectionString("GHIPUserStatusApiKey");
            AppConfig.ADByPassUsers = Configuration.GetConnectionString("ADByPassUsers");
            AppConfig.LipProvisionApi = Configuration.GetConnectionString("LipProvisionApi");
            AppConfig.LipProvisionAddUserApi = Configuration.GetConnectionString("LipProvisionAddUserApi");

            services
                .AddIdentity<AppUser, IdentityRole>(config =>
                {
                    config.Password.RequiredLength = 1;
                    config.Password.RequireDigit = false;
                    config.Password.RequireNonAlphanumeric = false;
                    config.Password.RequireUppercase = false;
                    config.Password.RequireLowercase = false;
                    config.User.AllowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\"-._@+#$%^*&!~`)(:;'*[]|/?><,";
                })
                .AddEntityFrameworkStores<AppIdentityDbContext>()
                .AddDefaultTokenProviders();
            /*    services.Configure<DataProtectionTokenProviderOptions>(opt =>
                      opt.TokenLifespan = TimeSpan.FromMinutes(30));*/
            string connectionString = Configuration.GetConnectionString("SQL");
            var migrationsAssembly = typeof(Startup).GetTypeInfo().Assembly.GetName().Name;
            services.AddCors(options =>
            {
                options.AddPolicy(
                    "CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
            });
            services.AddIdentityServer(options =>
            {
                options.Authentication.CookieLifetime = TimeSpan.FromDays(30);
                options.Authentication.CookieSlidingExpiration = true;
            })
                    .AddDeveloperSigningCredential()

                    // this adds the config data from DB (clients, resources, CORS)
                    .AddConfigurationStore(options =>
                    {
                        options.ConfigureDbContext = builder =>
                            builder.UseSqlServer(
                                connectionString,
                                sql => sql.MigrationsAssembly(migrationsAssembly));
                    })

                    // this adds the operational data from DB (codes, tokens, consents)
                    .AddOperationalStore(options =>
                     {
                         options.ConfigureDbContext = builder =>
                             builder.UseSqlServer(
                                 connectionString,
                                 sql => sql.MigrationsAssembly(migrationsAssembly));

                         // this enables automatic token cleanup. this is optional.
                         options.EnableTokenCleanup = true;
                         options.TokenCleanupInterval = 86400; // interval in seconds (default is 3600)
                     });

            Config.EmailSendApi = Configuration.GetConnectionString("EmailSendApi");
            Config.EmailSendApiKey = Configuration.GetConnectionString("EmailSendApiKey");
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = IdentityServerConstants.DefaultCookieAuthenticationScheme;
            });
            services.AddTransient<IProfileService, IdentityClaimsProfileService>();
            services.AddTransient<ISendEmailUtility, SendEmailUtility>();
            services.AddTransient<IOtpService, OtpService>();
            services.AddTransient<IDecryptUtility, DecryptUtility>();
            services.AddSingleton<ILoggerFactory, LoggerFactory>();
            services.AddSingleton(typeof(ILogger<>), typeof(Logger<>));
        }

        public void Configure(IApplicationBuilder app)
        {
            if (Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles();

            // InitializeDatabase(app);
/*            app.UseCookiePolicy(new CookiePolicyOptions
            {
                MinimumSameSitePolicy = SameSiteMode.Lax,
                Secure = CookieSecurePolicy.Always,
            });*/
            app.UseAuthentication();
            app.UseCors("CorsPolicy");
            app.UseRouting();
            app.UseIdentityServer();
            app.UseAuthorization();
            app.UseHttpsRedirection();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
            });
        }

        // Uncomment to add config to database
        private void InitializeDatabase(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                serviceScope.ServiceProvider.GetRequiredService<PersistedGrantDbContext>().Database.Migrate();

                var context = serviceScope.ServiceProvider.GetRequiredService<ConfigurationDbContext>();
                context.Database.Migrate();
                if (!context.Clients.Any())
                {
                    foreach (var client in Config.Clients)
                    {
                        context.Clients.Add(client.ToEntity());
                    }

                    context.SaveChanges();
                }

                if (!context.IdentityResources.Any())
                {
                    foreach (var resource in Config.Ids)
                    {
                        context.IdentityResources.Add(resource.ToEntity());
                    }

                    context.SaveChanges();
                }

                if (!context.ApiResources.Any())
                {
                    foreach (var resource in Config.Apis)
                    {
                        context.ApiResources.Add(resource.ToEntity());
                    }

                    context.SaveChanges();
                }
            }
        }
    }
}