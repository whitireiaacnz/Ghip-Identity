using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AspNetCore.ReCaptcha;
using IdentityModel;
using IdentityServer4.Events;
using IdentityServer4.Extensions;
using IdentityServer4.Services;
using IdentityServer4.Stores;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using RGI.IdentityServer.WebApp.Data;
using RGI.IdentityServer.WebApp.Helpers;
using RGI.IdentityServer.WebApp.Models;
using RGI.IdentityServer.WebApp.Services;
using RGI.IdentityServer.WebApp.Utility;

namespace RGI.IdentityServer.WebApp.Controllers
{
    /// <summary>
    /// This sample controller implements a typical login/logout/provision workflow for local and external accounts.
    /// The login service encapsulates the interactions with the user data store. This data store is in-memory only and cannot be used for production!
    /// The interaction service provides a way for the UI to communicate with identityserver for validation and context retrieval.
    /// </summary>
    [SecurityHeaders]
    [AllowAnonymous]
    public class AccountController : Controller
    {
        private readonly IIdentityServerInteractionService _interaction;
        private readonly IClientStore _clientStore;
        private readonly IAuthenticationSchemeProvider _schemeProvider;
        private readonly ILogger<AccountController> _logger;
        private readonly IEventService _events;
        private readonly UserManager<AppUser> _userManager;
        private readonly IMemoryCache _memoryCache;
        private readonly ISendEmailUtility _sendEmailUtility;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly IDecryptUtility _decryptUtility;
        private readonly IOtpService _otpService;

        public AccountController(
            IMemoryCache memoryCache,
            ISendEmailUtility sendEmailUtility,
            SignInManager<AppUser> signInManager,
            UserManager<AppUser> userManager,
            IIdentityServerInteractionService interaction,
            IAuthenticationSchemeProvider schemeProvider,
            ILogger<AccountController> logger,
            IClientStore clientStore,
            IEventService events,
            IDecryptUtility decryptUtility,
            IOtpService otpService,
            AppIdentityDbContext context)
        {
            _userManager = userManager;
            _interaction = interaction;
            _schemeProvider = schemeProvider;
            _logger = logger;
            _clientStore = clientStore;
            _events = events;
            _memoryCache = memoryCache;
            _sendEmailUtility = sendEmailUtility;
            _signInManager = signInManager;
            _decryptUtility = decryptUtility;
            _otpService = otpService;
        }

        private string CurrentOTP { get; set; }

        /// <summary>
        /// Entry point into the login workflow.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Login(string returnUrl)
        {
            // build a model so we know what to show on the login page
            _logger.LogInformation("Building a Login model");
            var vm = await BuildLoginViewModelAsync(returnUrl);
            if (vm.LoginType == "SSO")
            {
                return await SSOLogin(returnUrl);
            }

            if (!(vm.LoginType == "External" || vm.LoginType == "Internal"))
            {
                vm.InvalidLogin = true;
                return View(vm);
            }

            if (vm.IsExternalLoginOnly)
            {
                // we only have one option for logging in and it's an external provider
                _logger.LogInformation("External Provider");
                return RedirectToAction("Challenge", "External", new { provider = vm.ExternalLoginScheme, returnUrl });
            }

            return View(vm);
        }

        public async Task<IActionResult> SSOLogin(string returnUrl)
        {
            var context = await _interaction.GetAuthorizationContextAsync(returnUrl);
            string key = "b14ca5898a4e4133bbce2ea2315a1916";
            string code = returnUrl.Split("code=")[1];
            code = code.Replace(" ", "+");
            code = code.Replace("%2B", "+");
            code = code.Replace("%252F", "/");
            code = code.Replace("%2F", "/");
            code = code.Replace("%252B", "+");
            SSODecryptCredModel sSODecryptCredModel = JsonConvert.DeserializeObject<SSODecryptCredModel>(_decryptUtility.DecryptText(key, code));
            AppUser user = await _userManager.FindByNameAsync(sSODecryptCredModel.UserName);

            if (user == null)
            {
                return View();
            }

            _logger.LogInformation("Processing Internal Login");
            await _events.RaiseAsync(new UserLoginSuccessEvent(user.UserName, user.Id, user.Name));

            // issue authentication cookie with subject ID and username
            await HttpContext.SignInAsync(user.Id, user.UserName);

            if (context != null)
            {
                if (await _clientStore.IsPkceClientAsync(context.ClientId))
                {
                    // if the client is PKCE then we assume it's native, so this change in how to
                    // return the response is for better UX for the end user.
                    return View("Redirect", new RedirectViewModel { RedirectUrl = returnUrl });
                }

                // we can trust model.ReturnUrl since GetAuthorizationContextAsync returned non-null
                return Redirect(returnUrl);
            }

            return new OkResult();
        }

        [HttpPost]
        [Route("api/[controller]/Credentials/Decrypt")]
        public async Task<IActionResult> SaveDecryptedCredentials(DecryptionModel model)
        {
            string key = model.Key;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string decryptName = _decryptUtility.DecryptText(key, model.Username);
            string decryptemail = _decryptUtility.DecryptText(key, model.Email);
            string decryptPassword = _decryptUtility.DecryptText(key, model.Password);

            var user = new AppUser { UserName = decryptName, Email = decryptemail };
            var result = await _userManager.CreateAsync(user, decryptPassword);
            if (!result.Succeeded)
            {
                _logger.LogWarning("Bad request error");
                return BadRequest(result.Errors);
            }

            await _userManager.AddClaimAsync(user, new System.Security.Claims.Claim("userName", user.UserName));
            return Ok(user.Id);
        }

        [HttpPost]
        [Route("api/[controller]/provision")]
        public async Task<IActionResult> Provision(ProvisionModel model)
        {
            // var aVal = 0; var blowUp = 1 / aVal;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = new AppUser { UserName = model.Username, Email = model.Email };

            var result = await _userManager.CreateAsync(user, model.Password);

            if (!result.Succeeded)
            {
                _logger.LogWarning("Bad request error");
                return BadRequest(result.Errors);
            }

            if (model.WebsiteLoggedIn == "LIP")
            {
                CreateLipUserInternal(model, user.Id);
            }

            await _userManager.AddClaimAsync(user, new System.Security.Claims.Claim("userName", user.UserName));

            return Ok(user.Id);
        }

        [HttpDelete]
        [Route("api/[controller]/provision/{userId}")]
        public async Task<IActionResult> DeleteUser([FromRoute] string userId)
        {
            // var aVal = 0; var blowUp = 1 / aVal;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = await _userManager.FindByIdAsync(userId);

            var result = await _userManager.DeleteAsync(user);

            if (!result.Succeeded)
            {
                _logger.LogWarning("Bad request error");
                return BadRequest(result.Errors);
            }

            return Ok(user.Id);
        }

        public IActionResult SendEmailWithApi(EmailModel emailModel)
        {
            string url = Config.EmailSendApi;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("api_key", Config.EmailSendApiKey);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(Newtonsoft.Json.JsonConvert.SerializeObject(emailModel));
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "Accepted")
            {
                return new OkResult();
            }
            else
            {
                return new BadRequestObjectResult(response.ErrorMessage);
            }
        }

        /// <summary>
        /// Handle postback from username/password login.
        /// </summary>
        [ValidateReCaptcha]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginInputModel model, string button)
        {
            // check if we are in the context of an authorization request
            _logger.LogInformation("Login request received");
            var context = await _interaction.GetAuthorizationContextAsync(model.ReturnUrl);

            if (ModelState.IsValid)
            {
                string encryptedPassword = _decryptUtility.DecryptPasswordAES(model.Password);

                // validate username/password
                AppUser user = await _userManager.FindByNameAsync(model.Username);

                if (user == null)
                {
                    ModelState.AddModelError(string.Empty, AccountOptions.InvalidCredentialsErrorMessage);
                    var v = await BuildLoginViewModelAsync(model);
                    return View(v);
                }

                string userStatus = "Active";
                if (model.ReturnUrl.Contains("client_id=Ghip"))
                {
                    userStatus = IsUserEnabled(user.Id);
                }

                if (IsInternalLogin(model.LoginType) &&
                    (CallGhipInternal(model.Username, encryptedPassword) ||
                    CallLipInternal(model.Username, encryptedPassword, user.Id)))
                {
                    try
                    {
                        if (user.IsTwoFactorAuthenticationEnabled)
                        {
                            return RedirectToAction("OtpConfirmation", new { userId = user.Id, model.ReturnUrl, rememberLogin = model.RememberLogin });
                        }

                        _logger.LogInformation("Processing Internal Login");
                        await _events.RaiseAsync(new UserLoginSuccessEvent(user.UserName, user.Id, user.Name));

                        // only set explicit expiration here if user chooses "remember me".
                        // otherwise we rely upon expiration configured in cookie middleware.
                        AuthenticationProperties props = null;
                        if (AccountOptions.AllowRememberLogin && model.RememberLogin)
                        {
                            props = new AuthenticationProperties
                            {
                                IsPersistent = true,
                                ExpiresUtc = DateTimeOffset.UtcNow.Add(AccountOptions.RememberMeLoginDuration),
                            };
                        }

                        // issue authentication cookie with subject ID and username
                        await HttpContext.SignInAsync(user.Id, user.UserName, props);

                        // IsTwoFactorAuthenticationRequired(user, model.ReturnUrl);
                        if (context != null)
                        {
                            if (await _clientStore.IsPkceClientAsync(context.ClientId))
                            {
                                // if the client is PKCE then we assume it's native, so this change in how to
                                // return the response is for better UX for the end user.
                                return View("Redirect", new RedirectViewModel { RedirectUrl = model.ReturnUrl });
                            }

                            // we can trust model.ReturnUrl since GetAuthorizationContextAsync returned non-null
                            return Redirect(model.ReturnUrl);
                        }

                        // request for a local page
                        if (Url.IsLocalUrl(model.ReturnUrl))
                        {
                            return Redirect(model.ReturnUrl);
                        }
                        else if (string.IsNullOrEmpty(model.ReturnUrl))
                        {
                            return Redirect("~/");
                        }
                        else
                        {
                            // user might have clicked on a malicious link - should be logged
                            _logger.LogError("Invalid return URL");
                            throw new Exception("invalid return URL");
                        }
                    }
                    catch (Exception e)
                    {
                        _logger.LogError(e.Message);
                        await _events.RaiseAsync(new UserLoginFailureEvent(model.Username, "invalid credentials"));
                        ModelState.AddModelError(string.Empty, AccountOptions.InvalidCredentialsErrorMessage);

                        // something went wrong, show form with error
                        var v = await BuildLoginViewModelAsync(model);
                        return View(v);
                    }
                }
                else if (!IsInternalLogin(model.LoginType) && user != null)
                {
                    var checkValidPassword = false;
                    try
                    {
                        checkValidPassword = await _userManager.CheckPasswordAsync(user, encryptedPassword);
                    }
                    catch (Exception e)
                    {
                        _logger.LogError(e.Message);
                    }

                    if (checkValidPassword && userStatus == "Active")
                    {
                        await _events.RaiseAsync(new UserLoginSuccessEvent(user.UserName, user.Id, user.Name));

                        // only set explicit expiration here if user chooses "remember me".
                        // otherwise we rely upon expiration configured in cookie middleware.
                        AuthenticationProperties props = null;
                        if (AccountOptions.AllowRememberLogin && model.RememberLogin)
                        {
                            props = new AuthenticationProperties
                            {
                                IsPersistent = true,
                                ExpiresUtc = DateTimeOffset.UtcNow.Add(AccountOptions.RememberMeLoginDuration),
                                IssuedUtc = DateTimeOffset.UtcNow,
                                AllowRefresh = true,
                            };
                        }

                        // IsTwoFactorAuthenticationRequired(user, model.ReturnUrl);
                        if (user.IsTwoFactorAuthenticationEnabled)
                        {
                            return RedirectToAction("OtpConfirmation", new { user.Id, model.ReturnUrl });
                        }

                        // issue authentication cookie with subject ID and username
                        await HttpContext.SignInAsync(user.Id, user.UserName, props);

                        if (context != null)
                        {
                            if (await _clientStore.IsPkceClientAsync(context.ClientId))
                            {
                                // if the client is PKCE then we assume it's native, so this change in how to
                                // return the response is for better UX for the end user.
                                return View("Redirect", new RedirectViewModel { RedirectUrl = model.ReturnUrl });
                            }

                            // we can trust model.ReturnUrl since GetAuthorizationContextAsync returned non-null
                            return Redirect(model.ReturnUrl);
                        }

                        // request for a local page
                        if (Url.IsLocalUrl(model.ReturnUrl))
                        {
                            return Redirect(model.ReturnUrl);
                        }
                        else if (string.IsNullOrEmpty(model.ReturnUrl))
                        {
                            return Redirect("~/");
                        }
                        else
                        {
                            // user might have clicked on a malicious link - should be logged
                            throw new Exception("invalid return URL");
                        }
                    }
                }

                await _events.RaiseAsync(new UserLoginFailureEvent(model.Username, "Invalid credentials"));
                if (userStatus == "Disabled")
                {
                    ModelState.AddModelError(string.Empty, AccountOptions.DisabledUserErrorMessage);
                }
                else
                {
                    ModelState.AddModelError(string.Empty, AccountOptions.InvalidCredentialsErrorMessage);
                }
            }

            // something went wrong, show form with error
            var vm = await BuildLoginViewModelAsync(model);
            return View(vm);
        }

        [AllowAnonymous]
        public async Task<IActionResult> OtpConfirmation(string userId, string returnUrl, bool rememberLogin)
        {
            var user = await _userManager.FindByIdAsync(userId);

            if (string.IsNullOrEmpty(user.Email))
            {
                return RedirectToAction("CommunicationDetails", new { userId, returnUrl });
            }

            var token = await _otpService.GenerateOtpAsync(user.Id);

            SendOtpViaEmail(token, user.Email);

            var otpModel = new OtpModel()
            {
                ReturnUrl = returnUrl,
                UserId = userId,
                UserName = user.UserName,
            };
            return View(otpModel);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> OtpConfirmation(OtpModel twoFactor)
        {
            if (!ModelState.IsValid)
            {
                return View(twoFactor.TwoFactorCode);
            }

            var user = await _userManager.FindByIdAsync(twoFactor.UserId);
            if (twoFactor.TwoFactorCode == user.Otp && DateTime.UtcNow < user.OtpExpiry)
            {
                await HttpContext.SignInAsync(twoFactor.UserId, twoFactor.UserName);
                return Redirect(twoFactor.ReturnUrl ?? "/");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid OTP");
                return View();
            }
        }

        /// <summary>
        /// Show logout page.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Logout(string logoutId)
        {
            // build a model so the logout page knows what to display
            var vm = await BuildLogoutViewModelAsync(logoutId);

            if (vm.ShowLogoutPrompt == false)
            {
                // if the request for logout was properly authenticated from IdentityServer, then
                // we don't need to show the prompt and can just log the user out directly.
                _logger.LogInformation("Log out request");
                return await Logout(vm);
            }

            return View(vm);
        }

        [HttpGet]
        public IActionResult ResetPassword(string token, string userName)
        {
            var model = new ResetPasswordModel { Token = token, UserName = userName };
            if (!_memoryCache.TryGetValue(model.UserName, out string value) || value != model.Token.Replace(" ", "+"))
            {
                ModelState.AddModelError(string.Empty, "Link is Invalid/Expired.");
                ErrorModel errorModel = new ErrorModel()
                {
                    ErrorMessage = "This link has been expired or invalid.",
                };

                return View("ErrorView", errorModel);
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword(ResetPasswordModel resetPasswordModel)
        {
            if (!ModelState.IsValid)
            {
                return View(resetPasswordModel);
            }

            string capitalRegex = @"^(?=.*?[A-Z])";
            string lowerCaseRegex = @"^(?=.*?[a-z])";
            string digitRegex = @"^(?=.*?[0-9])";
            string specialCharRegex = @"^(?=.*?[#@$_])";

            if (!Regex.IsMatch(resetPasswordModel.Password, capitalRegex))
            {
                ModelState.AddModelError(string.Empty, "Password should contain at least one Uppercase.");

                return View();
            }

            if (!Regex.IsMatch(resetPasswordModel.Password, lowerCaseRegex))
            {
                ModelState.AddModelError(string.Empty, "Password should contain at least one Lowercase.");

                return View();
            }

            if (!Regex.IsMatch(resetPasswordModel.Password, digitRegex))
            {
                ModelState.AddModelError(string.Empty, "Password should contain at least one Digit.");

                return View();
            }

            if (!Regex.IsMatch(resetPasswordModel.Password, specialCharRegex))
            {
                ModelState.AddModelError(string.Empty, "Password should contain at least one Special Character allowed characters are @$#_");

                return View();
            }

            var user = await _userManager.FindByNameAsync(resetPasswordModel.UserName);
            if (user == null)
            {
                RedirectToAction(nameof(ResetPasswordConfirmation));
            }

            resetPasswordModel.Token = resetPasswordModel.Token.Replace(" ", "+");
            if (!_memoryCache.TryGetValue(resetPasswordModel.UserName, out string value) || value != resetPasswordModel.Token.Replace(" ", "+"))
            {
                ModelState.AddModelError(string.Empty, "Link is Invalid/Expired.");
                return View();
            }

            var resetPassResult = await _userManager.ResetPasswordAsync(user, resetPasswordModel.Token, resetPasswordModel.Password);
            if (!resetPassResult.Succeeded)
            {
                foreach (var error in resetPassResult.Errors)
                {
                    ModelState.TryAddModelError(error.Code, error.Description);
                }

                return View();
            }

            _memoryCache.Remove(resetPasswordModel.UserName);
            return RedirectToAction(nameof(ResetPasswordConfirmation));
        }

        [HttpGet]
        public IActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        /// <summary>
        /// Reset Password.
        /// </summary>
        [HttpPut("resetpassword")]
        public async Task<IActionResult> ResetPasswordByApi(ResetPasswordByApiModel user)
        {
            var appUser = await _userManager.FindByNameAsync(user.UserName);
            var code = await _userManager.GeneratePasswordResetTokenAsync(appUser);
            IdentityResult reset = await _userManager.ResetPasswordAsync(appUser, code, user.NewPassword);

            return new OkObjectResult(reset);
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [ValidateReCaptcha]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordModel forgotPasswordModel)
        {
            if (!ModelState.IsValid)
            {
                return View(forgotPasswordModel);
            }

            var user = await _userManager.FindByNameAsync(forgotPasswordModel.UserName);
            if (user == null)
            {
                // ModelState.AddModelError(string.Empty, "Username is Invalid.");
                // return View(forgotPasswordModel);
                return RedirectToAction(nameof(ForgotPasswordConfirmation));
            }

            if (string.IsNullOrEmpty(user.Email))
            {
                // ModelState.AddModelError(string.Empty, "Email not found for this UserName.");
                // return View(forgotPasswordModel);
                return RedirectToAction(nameof(ForgotPasswordConfirmation));
            }

            var token = await _userManager.GeneratePasswordResetTokenAsync(user);
            string callback = Url.Action(nameof(ResetPassword), "Account", new { token, userName = user.UserName }, Request.Scheme);
            string emailTemplate = _sendEmailUtility.GetForgetEmailTemplate(callback);
            EmailModel emailModel = new EmailModel()
            {
                Content = emailTemplate,
                Subject = "GHIP Reset password",
            };

            // Set cache options.
            var cacheEntryOptions = new MemoryCacheEntryOptions()

                // Keep in cache for this time, reset time if accessed.
                .SetSlidingExpiration(TimeSpan.FromMinutes(15));

            if (_memoryCache.TryGetValue(user.UserName, out string value))
            {
                _memoryCache.Remove(user.UserName);
            }

            // Save data in cache.
            _memoryCache.Set(user.UserName, token, cacheEntryOptions);
            emailModel.Personalizations.Add(new EmailPersonalizationsModel() { Recipient = user.Email, });
            _sendEmailUtility.SendEmailWithApi(emailModel);

            return RedirectToAction(nameof(ForgotPasswordConfirmation));
        }

        public IActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        /// <summary>
        /// Handle logout page postback.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout(LogoutInputModel model)
        {
            // build a model so the logged out page knows what to display
            var vm = await BuildLoggedOutViewModelAsync(model.LogoutId);

            if (User?.Identity.IsAuthenticated == true)
            {
                await HttpContext.SignOutAsync(IdentityServer4.IdentityServerConstants.DefaultCookieAuthenticationScheme);

                // delete local authentication cookie
                // await _signInManager.SignOutAsync();

                // raise the logout event
                await _events.RaiseAsync(new UserLogoutSuccessEvent(User.GetSubjectId(), User.GetDisplayName()));
            }

            // check if we need to trigger sign-out at an upstream identity provider
            if (vm.TriggerExternalSignout)
            {
                // build a return URL so the upstream provider will redirect back
                // to us after the user has logged out. this allows us to then
                // complete our single sign-out processing.
                string url = Url.Action("Logout", new { logoutId = vm.LogoutId });

                // this triggers a redirect to the external provider for sign-out
                return SignOut(new AuthenticationProperties { RedirectUri = url }, vm.ExternalAuthenticationScheme);
            }

            return View("LoggedOut", vm);
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            _logger.LogWarning("Access Denied");
            return View();
        }

        [HttpGet]
        public IActionResult SessionTimeOut()
        {
            _logger.LogWarning("Session TimeOut");
            return View();
        }

        [HttpGet]
        public IActionResult CommunicationDetails(string userId, string returnUrl)
        {
            var commModel = new CommunicationModel()
            {
                UserId = userId,
                ReturnUrl = returnUrl,
            };
            return View(commModel);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CommunicationDetails(CommunicationModel communicationModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            bool isEmail = Regex.IsMatch(communicationModel.Email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (string.IsNullOrEmpty(communicationModel.Email) || !isEmail)
            {
                ModelState.AddModelError(string.Empty, "Invalid Email");
                return View();
            }

            if (communicationModel.UserId != null)
            {
               await _otpService.SaveUserEmail(communicationModel.UserId, communicationModel.Email);
               return RedirectToAction("OtpConfirmation", new { communicationModel.UserId, communicationModel.ReturnUrl });
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid User");
                return View();
            }
        }

        /*****************************************/
        /* helper APIs for the AccountController */
        /*****************************************/

        private IActionResult IsTwoFactorAuthenticationRequired(AppUser user, string returnUrl)
        {
            if (user.IsTwoFactorAuthenticationEnabled)
            {
                return RedirectToAction("OtpConfirmation", new { user, returnUrl });
            }

            return default;
        }

        private void SendOtpViaEmail(string otp, string userEmail)
        {
            string emailTemplate = _sendEmailUtility.GetOtpEmailTemplate(otp);
            EmailModel emailModel = new EmailModel()
            {
                Content = emailTemplate,
                Subject = "GHIP one time password",
            };

            emailModel.Personalizations.Add(new EmailPersonalizationsModel() { Recipient = userEmail, });
            _sendEmailUtility.SendEmailWithApi(emailModel);
        }

        private async Task<LoginViewModel> BuildLoginViewModelAsync(string returnUrl)
        {
            _logger.LogWarning("Building a login view model");

            var context = await _interaction.GetAuthorizationContextAsync(returnUrl);
            if (context?.IdP != null && await _schemeProvider.GetSchemeAsync(context.IdP) != null)
            {
                var local = context.IdP == IdentityServer4.IdentityServerConstants.LocalIdentityProvider;

                // this is meant to short circuit the UI and only trigger the one external IdP
                var vm = new LoginViewModel
                {
                    EnableLocalLogin = local,
                    ReturnUrl = returnUrl,
                    Username = context?.LoginHint,
                };

                if (!local)
                {
                    vm.ExternalProviders = new[] { new ExternalProvider { AuthenticationScheme = context.IdP } };
                }

                return vm;
            }

            var schemes = await _schemeProvider.GetAllSchemesAsync();

            var providers = schemes
                .Where(x => x.DisplayName != null ||
                            x.Name.Equals(AccountOptions.WindowsAuthenticationSchemeName, StringComparison.OrdinalIgnoreCase))
                .Select(x => new ExternalProvider
                {
                    DisplayName = x.DisplayName,
                    AuthenticationScheme = x.Name,
                }).ToList();

            var allowLocal = true;
            if (context?.ClientId != null)
            {
                var client = await _clientStore.FindEnabledClientByIdAsync(context.ClientId);
                if (client != null)
                {
                    allowLocal = client.EnableLocalLogin;

                    if (client.IdentityProviderRestrictions != null && client.IdentityProviderRestrictions.Any())
                    {
                        providers = providers.Where(provider => client.IdentityProviderRestrictions.Contains(provider.AuthenticationScheme)).ToList();
                    }
                }
            }

            return new LoginViewModel
            {
                AllowRememberLogin = AccountOptions.AllowRememberLogin,
                EnableLocalLogin = allowLocal && AccountOptions.AllowLocalLogin,
                ReturnUrl = returnUrl,
                Username = context?.LoginHint,
                LoginType = context.Parameters.GetValues("loginType")[0],
                ExternalProviders = providers.ToArray(),
            };
        }

        private void OnTimerEvent(object sender, EventArgs e)
        {
            Response.Redirect("SessionTimeOut");
        }

        private async Task<LoginViewModel> BuildLoginViewModelAsync(LoginInputModel model)
        {
            var vm = await BuildLoginViewModelAsync(model.ReturnUrl);
            vm.Username = model.Username;
            vm.RememberLogin = model.RememberLogin;
            return vm;
        }

        private bool IsInternalLogin(string loginType)
        {
            _logger.LogInformation("Checking login type");
            return loginType == "Internal";
        }

        private string IsUserEnabled(string id)
        {
            _logger.LogInformation("Call Provision API");
            string url = AppConfig.GHIPUserStatusApi + id;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Key", AppConfig.GHIPUserStatusApiKey);
            IRestResponse response = client.Execute(request);
            try
            {
                if (Newtonsoft.Json.Linq.JObject.Parse(response.Content)["isActive"].ToString() == "True")
                {
                    return "Active";
                }
                else
                {
                    return "Disabled";
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return "NotFound";
            }
        }

        private bool CallGhipInternal(string userName, string password)
        {
            _logger.LogInformation("Call Provision API");
            string url = AppConfig.RelianceProvisionApi;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", AppConfig.RelianceProvisionApiKey);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("UserName", userName);
            request.AddParameter("LoginPassword", Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password)));
            IRestResponse response = client.Execute(request);
            try
            {
                if (Newtonsoft.Json.Linq.JObject.Parse(response.Content)["IsUserAuthenticated"].ToString() == "True")
                {
                    return true;
                }
                else
                {
                    List<string> users = AppConfig.ADByPassUsers.Split(",").ToList();
                    if (users.Contains(userName))
                    {
                        return password == "Hello@123456789";
                    }

                    return false;
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return false;
            }
        }

        private bool CallLipInternal(string userName, string password, string identityServiceUserId)
        {
            _logger.LogInformation("Call Provision API");
            string url = AppConfig.LipProvisionApi;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("UserName", userName);
            request.AddParameter("IdentityServiceUserId", identityServiceUserId);
            request.AddParameter("LoginPassword", Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password)));
            IRestResponse response = client.Execute(request);
            try
            {
                if (Newtonsoft.Json.Linq.JObject.Parse(response.Content)["isUserAuthenticated"].ToString() == "True")
                {
                    return true;
                }
                else
                {
                    List<string> users = AppConfig.ADByPassUsers.Split(",").ToList();
                    if (users.Contains(userName))
                    {
                        return password == "Hello@123456789";
                    }

                    return false;
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return false;
            }
        }

        private void CreateLipUserInternal(ProvisionModel model, string identityServerId)
        {
            _logger.LogInformation("Calling LIP create User API");

            try
            {
                string url = AppConfig.LipProvisionAddUserApi;
                RestClient client = new RestClient(url);
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddParameter("UserId", model.Username);
                request.AddParameter("UserName", model.Username);
                request.AddParameter("IdentityServiceUserId", identityServerId);
                request.AddParameter("RoleId", model.UserRole);

                IRestResponse response = client.Execute(request);

                if (Newtonsoft.Json.Linq.JObject.Parse(response.Content)["identityServiceUserId"].ToString() == identityServerId)
                {
                    _logger.LogInformation("LIP user creation success!");
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                _logger.LogInformation("LIP user creation failed!");
            }
        }

        private async Task<LogoutViewModel> BuildLogoutViewModelAsync(string logoutId)
        {
            _logger.LogError("Building a logout model");
            var vm = new LogoutViewModel { LogoutId = logoutId, ShowLogoutPrompt = AccountOptions.ShowLogoutPrompt };

            if (User?.Identity.IsAuthenticated != true)
            {
                // if the user is not authenticated, then just show logged out page
                vm.ShowLogoutPrompt = false;
                return vm;
            }

            var context = await _interaction.GetLogoutContextAsync(logoutId);
            if (context?.ShowSignoutPrompt == false)
            {
                // it's safe to automatically sign-out
                vm.ShowLogoutPrompt = false;
                return vm;
            }

            // show the logout prompt. this prevents attacks where the user
            // is automatically signed out by another malicious web page.
            return vm;
        }

        private async Task<LoggedOutViewModel> BuildLoggedOutViewModelAsync(string logoutId)
        {
            // get context information (client name, post logout redirect URI and iframe for federated signout)
            _logger.LogInformation("Building a logout view model");
            var logout = await _interaction.GetLogoutContextAsync(logoutId);

            var vm = new LoggedOutViewModel
            {
                AutomaticRedirectAfterSignOut = AccountOptions.AutomaticRedirectAfterSignOut,
                PostLogoutRedirectUri = logout?.PostLogoutRedirectUri,
                ClientName = string.IsNullOrEmpty(logout?.ClientName) ? logout?.ClientId : logout?.ClientName,
                SignOutIframeUrl = logout?.SignOutIFrameUrl,
                LogoutId = logoutId,
            };

            if (User?.Identity.IsAuthenticated == true)
            {
                _logger.LogInformation("Checking if user is authenticated");
                var idp = User.FindFirst(JwtClaimTypes.IdentityProvider)?.Value;
                if (idp != null && idp != IdentityServer4.IdentityServerConstants.LocalIdentityProvider)
                {
                    var providerSupportsSignout = await HttpContext.GetSchemeSupportsSignOutAsync(idp);
                    if (providerSupportsSignout)
                    {
                        if (vm.LogoutId == null)
                        {
                            // if there's no current logout context, we need to create one
                            // this captures necessary info from the current logged in user
                            // before we signout and redirect away to the external IdP for signout
                            vm.LogoutId = await _interaction.CreateLogoutContextAsync();
                        }

                        vm.ExternalAuthenticationScheme = idp;
                    }
                }
            }

            return vm;
        }
    }
}
