﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.IdentityServer.WebApp.Data.Migrations.IdentityServer.PersistedGrantDb
{
    public partial class InitialPersistedGrantDbMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
