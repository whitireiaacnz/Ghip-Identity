﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.IdentityServer.WebApp.Data.Migrations.IdentityServer.ConfigurationDb
{
    public partial class InitialConfigurationDbMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
