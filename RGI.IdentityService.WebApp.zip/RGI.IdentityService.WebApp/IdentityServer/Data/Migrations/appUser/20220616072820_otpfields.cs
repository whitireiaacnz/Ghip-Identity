﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.IdentityServer.WebApp.Data.Migrations.AppUser
{
    public partial class Otpfields : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "LastOtpSentAt",
                table: "AppUser",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "Otp",
                table: "AppUser",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "OtpExpiry",
                table: "AppUser",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LastOtpSentAt",
                table: "AppUser");

            migrationBuilder.DropColumn(
                name: "Otp",
                table: "AppUser");

            migrationBuilder.DropColumn(
                name: "OtpExpiry",
                table: "AppUser");
        }
    }
}
