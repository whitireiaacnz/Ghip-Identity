﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.IdentityServer.WebApp.Data.Migrations.AppUser
{
    public partial class TwoFAFiledAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsTwoFactorAuthenticationEnabled",
                table: "AppUser",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsTwoFactorAuthenticationEnabled",
                table: "AppUser");
        }
    }
}
