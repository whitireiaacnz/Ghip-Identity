﻿using System;
using Microsoft.AspNetCore.Identity;

namespace RGI.IdentityServer.WebApp.Data
{
    public class AppUser : IdentityUser
    {
        public string Name { get; set; }

        public string Otp { get; set; }

        public DateTime OtpExpiry { get; set; }

        public DateTime LastOtpSentAt { get; set; }

        public bool IsTwoFactorAuthenticationEnabled { get; set; }
    }
}
